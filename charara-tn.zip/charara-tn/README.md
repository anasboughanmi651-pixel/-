# 𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡
تطبيق أندرويد خفيف لتحميل فيديو/صوت من فيسبوك، تيك توك وانستا. بلا إعلانات.

1. ارفع المشروع على GitHub (branch: main)
2. تبويب Actions ← Build APK ← Run workflow
3. بعد ما يكمل، نزّل Tahmil-apk من Artifacts وثبّت الـ APK
