import json
import os
import urllib.parse
import urllib.request

import yt_dlp

UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"


def _ytdlp(url, out_dir, cookies):
    opts = {
        "outtmpl": os.path.join(out_dir, "%(id)s.%(ext)s"),
        "format": "best[ext=mp4]/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
    }
    if cookies:
        opts["cookiefile"] = cookies
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = ydl.prepare_filename(info)
        title = info.get("title") or info.get("id") or "video"
    return [title, path]


def _tikwm(url, out_dir):
    api = "https://www.tikwm.com/api/?hd=1&url=" + urllib.parse.quote(url, safe="")
    j = json.load(urllib.request.urlopen(urllib.request.Request(api, headers={"User-Agent": UA}), timeout=30))
    if j.get("code") != 0:
        raise Exception(j.get("msg") or "no result")
    d = j["data"]
    src = d.get("hdplay") or d.get("play")
    if not src:
        raise Exception("no media url")
    if src.startswith("/"):
        src = "https://www.tikwm.com" + src
    path = os.path.join(out_dir, str(d.get("id", "tiktok")) + ".mp4")
    with urllib.request.urlopen(urllib.request.Request(src, headers={"User-Agent": UA}), timeout=60) as r, open(path, "wb") as f:
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b)
    return [d.get("title") or d.get("id") or "tiktok", path]


def download(url, out_dir, cookies=""):
    err = None
    try:
        return _ytdlp(url, out_dir, cookies)
    except Exception as e:
        err = e
    if cookies and "instagram" in url:
        try:
            return _ytdlp(url, out_dir, "")
        except Exception as e:
            err = e
    if "tiktok" in url:
        try:
            return _tikwm(url, out_dir)
        except Exception as e:
            err = Exception("TikTok a refusé le lien (" + str(e)[:60] + ")")
    raise err
