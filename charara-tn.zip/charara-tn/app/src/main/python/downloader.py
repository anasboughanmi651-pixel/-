import os
import yt_dlp


def download(url, mode, out_dir):
    fmt = "best[ext=mp4]/best" if mode == "video" else "bestaudio[ext=m4a]/bestaudio/best"
    opts = {
        "outtmpl": os.path.join(out_dir, "%(id)s.%(ext)s"),
        "format": fmt,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = ydl.prepare_filename(info)
        title = info.get("title") or info.get("id") or "video"
    return [title, path]
