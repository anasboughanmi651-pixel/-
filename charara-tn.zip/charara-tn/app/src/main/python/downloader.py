import json
import os
import re
import socket
import time
import urllib.parse
import urllib.request

import yt_dlp

UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
UA_PC = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

STATE = "-1|Analyse du lien…"
CANCEL = False

_orig_gai = socket.getaddrinfo


def _ipv4(host, port, family=0, type=0, proto=0, flags=0):
    return _orig_gai(host, port, socket.AF_INET, type, proto, flags)


socket.getaddrinfo = _ipv4


def progress():
    return STATE


def cancel():
    global CANCEL
    CANCEL = True


def _set(pct, text):
    global STATE
    STATE = "%d|%s" % (pct, text)


def _check():
    if CANCEL:
        raise Exception("Annulé")


def _hook(d):
    _check()
    if d.get("status") == "downloading":
        tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes") or 0
        pct = int(done * 100 / tot) if tot else -1
        txt = ("Téléchargement %d %%" % pct) if pct >= 0 else "Téléchargement…"
        if d.get("speed"):
            txt += " • %d Ko/s" % (d["speed"] / 1024)
        if d.get("eta"):
            txt += " • %d s restantes" % d["eta"]
        _set(pct, txt)
    elif d.get("status") == "finished":
        _set(100, "Finalisation…")


def _get(url, ua=UA):
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept-Language": "en-US,en;q=0.9"})
    return urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")


def _save_url(src, out_dir, name, ua=UA):
    path = os.path.join(out_dir, name + ".mp4")
    with urllib.request.urlopen(urllib.request.Request(src, headers={"User-Agent": ua}), timeout=60) as r, open(path, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            _check()
            b = r.read(65536)
            if not b:
                break
            f.write(b)
            done += len(b)
            if total:
                p = int(done * 100 / total)
                _set(p, "Téléchargement %d %%" % p)
    return path


def _ytdlp(url, out_dir, cookies, maxh):
    opts = {
        "outtmpl": os.path.join(out_dir, "%(id)s.%(ext)s"),
        "format": "best[height<=%d][ext=mp4]/best[ext=mp4]/best/bestvideo[ext=mp4]/bestvideo" % maxh,
        "noplaylist": True,
        "playlist_items": "1",
        "retries": 3,
        "extractor_retries": 2,
        "socket_timeout": 30,
        "progress_hooks": [_hook],
        "quiet": True,
        "no_warnings": True,
    }
    if cookies:
        opts["cookiefile"] = cookies
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        if info.get("entries"):
            info = next(e for e in info["entries"] if e)
        rd = info.get("requested_downloads") or []
        path = rd[0]["filepath"] if rd and rd[0].get("filepath") else ydl.prepare_filename(info)
        title = info.get("title") or info.get("id") or "video"
    return [title, path]


def _tikwm(url, out_dir):
    api = "https://www.tikwm.com/api/?hd=1&url=" + urllib.parse.quote(url, safe="")
    j = json.loads(_get(api))
    if j.get("code") != 0:
        raise Exception(j.get("msg") or "no result")
    d = j["data"]
    src = d.get("hdplay") or d.get("play")
    if not src:
        raise Exception("no media url")
    if src.startswith("/"):
        src = "https://www.tikwm.com" + src
    return [d.get("title") or d.get("id") or "tiktok", _save_url(src, out_dir, "tt_" + str(d.get("id", "x")))]


def _ig_embed(url, out_dir):
    m = re.search(r"/(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)", url)
    if not m:
        raise Exception("no shortcode")
    code = m.group(1)
    html = _get("https://www.instagram.com/p/%s/embed/captioned/" % code, UA_PC)
    v = re.search(r'"video_url":"(.*?)"', html)
    if not v:
        raise Exception("no video in embed")
    return ["instagram " + code, _save_url(json.loads('"' + v.group(1) + '"'), out_dir, "ig_" + code, UA_PC)]


def _fb_scrape(url, out_dir):
    html = _get(url, UA_PC)
    for key in ("browser_native_hd_url", "browser_native_sd_url", "hd_src", "sd_src"):
        v = re.search(r'"%s":"(.*?)"' % key, html)
        if v:
            name = "fb_" + str(abs(hash(url)))
            return ["facebook video", _save_url(json.loads('"' + v.group(1) + '"'), out_dir, name, UA_PC)]
    raise Exception("no video found")


def download(url, out_dir, ig_ck="", fb_ck="", maxh=720):
    global CANCEL
    CANCEL = False
    _set(-1, "Analyse du lien…")
    u = url.lower()
    is_fb = "facebook" in u or "fb.watch" in u or "fb.com" in u
    ck = ig_ck if "instagram" in u else (fb_ck if is_fb else "")
    steps = []
    if ck:
        steps.append(lambda: _ytdlp(url, out_dir, ck, maxh))
    steps.append(lambda: _ytdlp(url, out_dir, "", maxh))
    if "tiktok" in u:
        steps.append(lambda: _tikwm(url, out_dir))
    if "instagram" in u:
        steps.append(lambda: _ig_embed(url, out_dir))
    if is_fb:
        steps.append(lambda: _fb_scrape(url, out_dir))
    errs = []
    t0 = time.time()
    for s in steps:
        _check()
        if errs and time.time() - t0 > 300:
            break
        try:
            return s()
        except Exception as e:
            if CANCEL:
                raise Exception("Annulé")
            errs.append(str(e))
            _set(-1, "Nouvelle tentative…")
    raise Exception(errs[0] if errs else "echec")
