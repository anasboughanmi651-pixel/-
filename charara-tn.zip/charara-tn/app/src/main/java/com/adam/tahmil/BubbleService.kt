package com.adam.tahmil

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "stop" -> { stopSelf(); return START_NOT_STICKY }
            "dl" -> { download(i.getStringExtra("url") ?: ""); return START_STICKY }
        }
        startForeground(1, notif("Bouton flottant actif 🔵"))
        if (bubble == null) addBubble()
        return START_STICKY
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "CHARARA TN", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, BubbleService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "c")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡").setContentText(text).setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Arrêter", stop).build()).build()
    }

    private fun toast(t: String) = ui.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun download(url: String) {
        toast("⏳ Téléchargement…")
        Thread {
            try {
                Saver.fetch(applicationContext, url)
                toast("✅ Terminé ! Voir dans la Galerie")
            } catch (e: Throwable) {
                toast("❌ ${Saver.fail(applicationContext, e)}")
            }
        }.start()
    }

    private fun launch() {
        startActivity(Intent(this, ClipActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun addBubble() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val s = (56 * resources.displayMetrics.density).toInt()
        val v = ImageView(this).apply {
            setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.CENTER_CROP
            setPadding(5, 5, 5, 5); alpha = .92f; elevation = 12f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK); setStroke(5, Color.parseColor("#A78BFA")) }
            outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 400 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > 12 || abs(dy) > 12) { moved = true }
                    if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> { if (!moved) launch() }
            }
            true
        }
        wm.addView(v, lp); bubble = v
    }

    override fun onDestroy() {
        bubble?.let { if (::wm.isInitialized) wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }
}
