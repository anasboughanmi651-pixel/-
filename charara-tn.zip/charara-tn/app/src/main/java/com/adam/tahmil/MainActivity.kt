package com.adam.tahmil

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btnV: Button
    private lateinit var btnA: Button
    private lateinit var sw: Switch
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * d).toInt()
    private val title = "𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡"

    private fun shape(c1: String, c2: String = c1, r: Int = 16, stroke: String? = null) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply {
            cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), Color.parseColor(stroke))
        }

    private fun tv(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, a: String, b: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; isAllCaps = false
        background = shape(a, b, 18); setOnClickListener { f() }
    }

    private fun rounded(v: ImageView, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(52), dp(20), dp(24)); layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.parseColor("#1A0B2E")))
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo); rounded(this, 26); elevation = dp(12).toFloat() }
        page.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)))
        page.addView(tv(title, 24f, "#FFFFFF", true).apply { setPadding(0, dp(12), 0, 0); letterSpacing = .06f })
        page.addView(tv("فيسبوك • تيك توك • انستا", 13f, "#A78BFA"))

        input = EditText(this).apply {
            hint = "الصق الرابط هنا"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true)
            background = shape("#1AFFFFFF", "#1AFFFFFF", 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        btnV = btn("🎬 فيديو", "#E11D48", "#8B5CF6") { start("video") }
        btnA = btn("🎵 صوت", "#8B5CF6", "#2563EB") { start("audio") }
        bar = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        status = tv("", 14f, "#CBD5E1")
        sw = Switch(this).apply {
            text = "🫧 الزر العائم (فوق كل التطبيقات)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on -> if (on) enableBubble() else stopService(Intent(this@MainActivity, BubbleService::class.java)) }
        }
        val row = LinearLayout(this).apply {
            val lp = { LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(4), 0, dp(4), 0) } }
            addView(btnV, lp()); addView(btnA, lp())
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            background = shape("#14FFFFFF", "#14FFFFFF", 24, "#33A78BFA")
            addView(input)
            addView(btn("📋 لصق من الحافظة", "#334155", "#334155") { paste() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10); bottomMargin = dp(10) })
            addView(row); addView(bar); addView(status)
        }
        page.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        page.addView(sw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        page.addView(tv("اضغط الزر = فيديو  •  اضغط مطوّل = صوت\nانسخ الرابط من التطبيق ثم اضغط الزر العائم", 12f, "#94A3B8").apply { setPadding(0, dp(8), 0, 0) })
        page.addView(tv("by آدم الهدياوي", 12f, "#64748B").apply { setPadding(0, dp(32), 0, 0) })

        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK)
            val l = ImageView(this@MainActivity).apply { setImageResource(R.drawable.logo); rounded(this, 34); alpha = 0f; scaleX = .5f; scaleY = .5f }
            val n = tv(title, 26f, "#FFFFFF", true).apply { alpha = 0f; letterSpacing = .06f; setPadding(0, dp(20), 0, 0) }
            addView(l, LinearLayout.LayoutParams(dp(140), dp(140))); addView(n)
            l.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
            n.animate().alpha(1f).setStartDelay(400).setDuration(600).start()
            postDelayed({ animate().alpha(0f).setDuration(500).withEndAction { visibility = View.GONE }.start() }, 1700)
        }
        val root = FrameLayout(this)
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(page) })
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { t -> Saver.link(t)?.let { input.setText(it) } }
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        input.setText(Saver.link(t) ?: t)
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل الإذن ثم ارجع وشغّل الزر", Toast.LENGTH_LONG).show()
            sw.isChecked = false; return
        }
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, BubbleService::class.java))
    }

    private fun busy(b: Boolean) {
        bar.visibility = if (b) View.VISIBLE else View.GONE
        btnV.isEnabled = !b; btnA.isEnabled = !b
    }

    private fun start(mode: String) {
        val url = Saver.link(input.text.toString())
        if (url == null) { status.text = "⚠️ الصق رابط صحيح من فيسبوك أو تيك توك أو انستا"; return }
        busy(true); status.text = "⏳ جاري التحميل..."
        Thread {
            try {
                val n = Saver.fetch(applicationContext, url, mode)
                runOnUiThread { status.text = "✅ تم! تلقاه في المعرض\n$n"; busy(false) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "❌ ${e.message?.take(200)}"; busy(false) }
            }
        }.start()
    }
}
