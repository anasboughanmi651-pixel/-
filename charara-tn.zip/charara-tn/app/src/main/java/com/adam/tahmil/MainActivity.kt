package com.adam.tahmil

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btnDl: Button
    private lateinit var sw: Switch
    private var refreshAcc: () -> Unit = {}

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val page = Ui.page(c)

        page.addView(LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(c).apply { setImageResource(R.drawable.logo); Ui.rounded(c, this, 12) }, LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
            addView(Ui.tv(c, Ui.APP, 18f, bold = true).apply { setPadding(Ui.dp(c, 12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.tv(c, "⚙️", 24f).apply {
                setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 4), Ui.dp(c, 8))
                setOnClickListener { startActivity(Intent(c, SettingsActivity::class.java)) }
            })
        })
        page.addView(Ui.tv(c, "Télécharger une vidéo", 24f, bold = true), Ui.lp(c, 28))
        page.addView(Ui.tv(c, "Facebook • TikTok • Instagram (Reels)", 13f, "#A78BFA"), Ui.lp(c, 4))

        input = EditText(c).apply {
            hint = "Collez le lien de la vidéo"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true)
            background = Ui.shape(c, "#1AFFFFFF", "#1AFFFFFF", 14); setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
        }
        bar = ProgressBar(c).apply { isIndeterminate = true; visibility = View.GONE }
        status = Ui.tv(c, "", 13f, "#CBD5E1", center = true)
        btnDl = Ui.btn(c, "⬇  Télécharger", "#E11D48", "#8B5CF6") { start() }
        val row = LinearLayout(c).apply {
            addView(Ui.btn(c, "Coller", "#334155", "#334155") { paste() }, LinearLayout.LayoutParams(0, Ui.dp(c, 50), 1f).apply { marginEnd = Ui.dp(c, 8) })
            addView(btnDl, LinearLayout.LayoutParams(0, Ui.dp(c, 50), 2f))
        }
        page.addView(Ui.card(c).apply { addView(input); addView(row, Ui.lp(c, 12)); addView(bar); addView(status) }, Ui.lp(c, 16))
        val (acc, r) = Ui.accounts(c); refreshAcc = r
        page.addView(acc, Ui.lp(c, 12))

        sw = Switch(c).apply {
            text = "Bouton flottant"; setTextColor(Color.WHITE); textSize = 16f
            setOnCheckedChangeListener { _, on -> if (on) enableBubble() else stopService(Intent(c, BubbleService::class.java)) }
        }
        page.addView(Ui.card(c).apply {
            addView(sw)
            addView(Ui.tv(c, "Un bouton toujours visible : copiez le lien d'une vidéo, appuyez dessus, et la vidéo arrive dans votre Galerie.", 12f, "#94A3B8"), Ui.lp(c, 6))
        }, Ui.lp(c, 12))
        page.addView(Ui.card(c).apply {
            addView(Ui.tv(c, "Comment ça marche", 15f, "#C4B5FD", true))
            addView(Ui.tv(c, "1. Dans l'appli : Partager → Copier le lien\n2. Collez-le ici, puis Télécharger\n3. La vidéo est dans la Galerie (album CHARARA TN)", 13f, "#CBD5E1"), Ui.lp(c, 6))
        }, Ui.lp(c, 12))
        page.addView(Ui.footer(c), Ui.lp(c, 28))

        val splash = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK)
            val l = ImageView(c).apply { setImageResource(R.drawable.logo); Ui.rounded(c, this, 34); alpha = 0f; scaleX = .5f; scaleY = .5f }
            val n = Ui.tv(c, Ui.APP, 26f, bold = true).apply { alpha = 0f; letterSpacing = .06f; setPadding(0, Ui.dp(c, 20), 0, 0) }
            addView(l, LinearLayout.LayoutParams(Ui.dp(c, 140), Ui.dp(c, 140))); addView(n)
            l.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
            n.animate().alpha(1f).setStartDelay(400).setDuration(600).start()
            postDelayed({ animate().alpha(0f).setDuration(500).withEndAction { visibility = View.GONE }.start() }, 1700)
        }
        val root = FrameLayout(c)
        root.addView(ScrollView(c).apply { isFillViewport = true; addView(page) })
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        if (Build.VERSION.SDK_INT < 29) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
        handleIntent(intent)
        Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) askAccounts() }, 2300)
    }

    override fun onResume() { super.onResume(); refreshAcc() }

    private fun askAccounts() {
        val p = getSharedPreferences("app", Context.MODE_PRIVATE)
        if (p.getBoolean("asked", false)) return
        p.edit().putBoolean("asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Connexion (optionnelle)")
            .setMessage("Connectez-vous une seule fois à Instagram ou Facebook pour télécharger plus de vidéos sans erreur. Votre session reste sur votre téléphone. Vous pouvez aussi continuer sans compte.")
            .setPositiveButton("Instagram") { _, _ -> startActivity(Intent(this, LoginActivity::class.java).putExtra("site", "instagram")) }
            .setNeutralButton("Facebook") { _, _ -> startActivity(Intent(this, LoginActivity::class.java).putExtra("site", "facebook")) }
            .setNegativeButton("Plus tard", null).show()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { t -> Saver.link(t)?.let { input.setText(it) } }
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        input.setText(Saver.link(t) ?: t)
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Autorisez l'affichage par-dessus les autres applis, puis revenez activer le bouton", Toast.LENGTH_LONG).show()
            sw.isChecked = false; return
        }
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, BubbleService::class.java))
    }

    private fun busy(b: Boolean) {
        bar.visibility = if (b) View.VISIBLE else View.GONE
        btnDl.isEnabled = !b
    }

    private var job = 0

    private fun start() {
        val url = Saver.link(input.text.toString())
        if (url == null) { status.text = "⚠️ Collez un lien Facebook, TikTok ou Instagram"; return }
        val my = ++job
        busy(true)
        val t0 = System.currentTimeMillis()
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                if (job != my) return
                val sec = (System.currentTimeMillis() - t0) / 1000
                if (sec > 100) {
                    job++; busy(false)
                    status.text = "❌ Délai dépassé. Vérifiez que Facebook/Instagram s'ouvrent sur ce téléphone (Réglages → Diagnostic)."
                    return
                }
                status.text = "⏳ Téléchargement en cours… $sec s"
                h.postDelayed(this, 1000)
            }
        })
        Thread {
            try {
                val n = Saver.fetch(applicationContext, url)
                runOnUiThread { if (job == my) { job++; status.text = "✅ Terminé ! Retrouvez-la dans la Galerie\n$n"; busy(false) } }
            } catch (e: Throwable) {
                val msg = Saver.fail(applicationContext, e)
                runOnUiThread { if (job == my) { job++; status.text = "❌ $msg"; busy(false) } }
            }
        }.start()
    }
}
