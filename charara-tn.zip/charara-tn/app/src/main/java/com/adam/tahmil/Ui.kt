package com.adam.tahmil

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*

object Ui {
    const val APP = "𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡"
    const val BY = "𝗕𝗬 : 𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗕𝗔𝗖𝗞"
    const val OWNER = "𝗔𝗗𝗘𝗠 𝗛𝗔𝗗𝗬𝗔𝗢𝗨𝗜"

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, c1: String, c2: String = c1, r: Int = 16, stroke: String? = null) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply {
            cornerRadius = dp(c, r).toFloat(); if (stroke != null) setStroke(dp(c, 1), Color.parseColor(stroke))
        }

    fun tv(c: Context, t: String, size: Float, color: String = "#FFFFFF", bold: Boolean = false, center: Boolean = false) =
        TextView(c).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
            if (center) gravity = Gravity.CENTER
        }

    fun btn(c: Context, t: String, a: String, b: String, f: () -> Unit) = Button(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; isAllCaps = false
        background = shape(c, a, b, 16); setOnClickListener { f() }
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16))
        background = shape(c, "#14FFFFFF", "#14FFFFFF", 20, "#26A78BFA")
    }

    fun page(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(c, 20), dp(c, 44), dp(c, 20), dp(c, 28))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.parseColor("#1A0B2E")))
    }

    fun lp(c: Context, top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, top) }

    fun rounded(c: Context, v: ImageView, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(c, r).toFloat()) }
        }
    }

    fun footer(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        addView(tv(c, BY, 12f, "#64748B", center = true))
        addView(tv(c, OWNER, 13f, "#A78BFA", bold = true, center = true), lp(c, 4))
    }

    fun accounts(c: Activity): Pair<LinearLayout, () -> Unit> {
        val ups = mutableListOf<() -> Unit>()
        val card = card(c).apply {
            addView(tv(c, "Comptes (optionnel)", 15f, "#C4B5FD", true))
            addView(tv(c, "Connectez-vous une seule fois : vos téléchargements Instagram et Facebook seront plus fiables. Sans compte, les vidéos publiques fonctionnent aussi. Votre session reste sur votre téléphone.", 12f, "#94A3B8"), lp(c, 6))
            for ((site, label) in listOf("instagram" to "Instagram", "facebook" to "Facebook")) {
                val st = tv(c, "", 13f, "#CBD5E1", true)
                val b = btn(c, "", "#E11D48", "#8B5CF6") {}
                fun upd() {
                    val on = Saver.cookieFile(c, site).exists()
                    st.text = label + " : " + (if (on) "● connecté" else "○ non connecté")
                    b.text = if (on) "Se déconnecter" else "Se connecter"
                    b.setOnClickListener {
                        if (on) { Saver.cookieFile(c, site).delete(); upd() }
                        else c.startActivity(Intent(c, LoginActivity::class.java).putExtra("site", site))
                    }
                }
                ups.add { upd() }
                addView(st, lp(c, 12))
                addView(b, LinearLayout.LayoutParams(-1, dp(c, 46)).apply { topMargin = dp(c, 6) })
            }
        }
        val refresh = { ups.forEach { it() } }
        refresh()
        return Pair(card, refresh)
    }
}
