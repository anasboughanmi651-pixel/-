package com.adam.tahmil

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

object Saver {
    private val urlRx = Regex("https?://\\S+")
    private val okRx = Regex("(facebook\\.com|fb\\.watch|fb\\.com|tiktok\\.com|instagram\\.com)")

    fun link(t: String): String? = urlRx.find(t)?.value?.takeIf { okRx.containsMatchIn(it) }

    fun fetch(ctx: Context, url: String, mode: String): String {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx))
        val r = Python.getInstance().getModule("downloader")
            .callAttr("download", url, mode, ctx.cacheDir.absolutePath).asList()
        val f = File(r[1].toString())
        return save(ctx, f, r[0].toString(), mode == "audio").also { f.delete() }
    }

    private fun save(ctx: Context, f: File, title: String, audio: Boolean): String {
        val ext = f.extension.lowercase()
        val name = title.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").take(60) + "." + ext
        val mime = if (audio) (if (ext == "webm") "audio/webm" else "audio/mp4")
                   else (if (ext == "webm") "video/webm" else "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, (if (audio) "Music/" else "Movies/") + "CHARARA TN")
            }
            val col = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = ctx.contentResolver.insert(col, cv)!!
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        } else {
            val base = Environment.getExternalStoragePublicDirectory(if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES)
            val dir = File(base, "CHARARA TN").apply { mkdirs() }
            val out = File(dir, name)
            f.copyTo(out, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf(mime), null)
        }
        return name
    }
}
