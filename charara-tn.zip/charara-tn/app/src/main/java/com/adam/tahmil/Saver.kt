package com.adam.tahmil

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

object Saver {
    const val COOKIES = "ig_cookies.txt"
    private val urlRx = Regex("https?://\\S+")
    private val okRx = Regex("(facebook\\.com|fb\\.watch|fb\\.com|tiktok\\.com|instagram\\.com)")

    fun link(t: String): String? = urlRx.find(t)?.value?.takeIf { okRx.containsMatchIn(it) }

    fun friendly(e: Exception): String {
        val m = e.message ?: ""
        return when {
            m.contains("login", true) || m.contains("rate-limit", true) || m.contains("cookies", true) ->
                "Instagram demande une connexion : Réglages ⚙️ → Se connecter à Instagram"
            m.contains("Unsupported URL", true) -> "Lien non pris en charge : copiez le lien d'une vidéo"
            m.contains("resolve host", true) || m.contains("urlopen", true) || m.contains("Network", true) -> "Pas de connexion Internet"
            else -> m.take(120)
        }
    }

    fun fetch(ctx: Context, url: String): String {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx))
        val ck = File(ctx.filesDir, COOKIES)
        val r = Python.getInstance().getModule("downloader")
            .callAttr("download", url, ctx.cacheDir.absolutePath, if (ck.exists()) ck.absolutePath else "").asList()
        val f = File(r[1].toString())
        return save(ctx, f, r[0].toString()).also { f.delete() }
    }

    private fun save(ctx: Context, f: File, title: String): String {
        val ext = f.extension.lowercase()
        val name = title.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").take(60).ifBlank { "video" } + "." + ext
        val mime = if (ext == "webm") "video/webm" else "video/mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/CHARARA TN")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "CHARARA TN").apply { mkdirs() }
            val out = File(dir, name)
            f.copyTo(out, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf(mime), null)
        }
        return name
    }
}
