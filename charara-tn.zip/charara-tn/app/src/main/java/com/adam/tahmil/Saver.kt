package com.adam.tahmil

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

object Saver {
    private val urlRx = Regex("https?://\\S+")
    private val okRx = Regex("(facebook\\.com|fb\\.watch|fb\\.com|tiktok\\.com|instagram\\.com)")

    fun link(t: String): String? = urlRx.find(t)?.value?.takeIf { okRx.containsMatchIn(it) }

    @Volatile var running = false
    @Volatile var message = ""
    @Volatile var startedAt = 0L

    fun progress(): String = try {
        if (!Python.isStarted()) "-1|Analyse du lien…"
        else Python.getInstance().getModule("downloader").callAttr("progress").toString()
    } catch (e: Throwable) { "-1|Analyse du lien…" }

    fun cancel() { try { if (Python.isStarted()) Python.getInstance().getModule("downloader").callAttr("cancel") } catch (e: Throwable) {} }

    fun parse(s: String): Pair<Int, String> {
        val i = s.indexOf('|')
        return if (i < 0) Pair(-1, s) else Pair(s.substring(0, i).toIntOrNull() ?: -1, s.substring(i + 1))
    }

    fun cookieFile(ctx: Context, site: String) = File(ctx.filesDir, if (site == "facebook") "fb_cookies.txt" else "ig_cookies.txt")

    fun friendly(e: Throwable): String {
        val m = e.message ?: e.toString()
        return when {
            m.contains("Annulé") -> "Téléchargement annulé"
            m.contains("no video in this post", true) -> "Cette publication ne contient pas de vidéo"
            m.contains("login", true) || m.contains("rate-limit", true) || m.contains("cookies", true) ||
                m.contains("Cannot parse", true) || m.contains("empty media", true) || m.contains("not available", true) ->
                "Cette vidéo demande une connexion : connectez votre compte Instagram ou Facebook (section Comptes)"
            m.contains("private", true) -> "Cette vidéo est privée ou supprimée"
            m.contains("Unexpected response", true) -> "TikTok a refusé le lien, réessayez dans un instant"
            m.contains("Unsupported URL", true) -> "Lien non pris en charge : copiez le lien d'une vidéo"
            m.contains("resolve host", true) || m.contains("urlopen", true) || m.contains("Network", true) -> "Pas de connexion Internet"
            else -> m.take(140)
        }
    }

    fun fail(ctx: Context, e: Throwable): String {
        runCatching { File(ctx.filesDir, "last_error.txt").writeText(e.message ?: e.toString()) }
        return friendly(e)
    }

    fun fetch(ctx: Context, url: String): String {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx))
        val ig = cookieFile(ctx, "instagram"); val fb = cookieFile(ctx, "facebook")
        val low = ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("low", false)
        val r = Python.getInstance().getModule("downloader")
            .callAttr("download", url, ctx.cacheDir.absolutePath,
                if (ig.exists()) ig.absolutePath else "", if (fb.exists()) fb.absolutePath else "", if (low) 480 else 720).asList()
        val f = File(r[1].toString())
        return save(ctx, f, r[0].toString()).also { f.delete() }
    }

    private fun save(ctx: Context, f: File, title: String): String {
        val ext = f.extension.lowercase()
        val name = title.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").take(60).ifBlank { "video" } + "." + ext
        val mime = if (ext == "webm") "video/webm" else "video/mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/CHARARA TN")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "CHARARA TN").apply { mkdirs() }
            val out = File(dir, name)
            f.copyTo(out, overwrite = true)
            MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf(mime), null)
        }
        return name
    }
}
