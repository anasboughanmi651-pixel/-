package com.adam.tahmil

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ClipActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val url = Saver.link(cm.primaryClip?.getItemAt(0)?.text?.toString() ?: "")
        if (url == null) {
            Toast.makeText(this, "📋 Copiez d'abord le lien de la vidéo, puis appuyez sur le bouton", Toast.LENGTH_LONG).show()
        } else {
            if (Saver.running) {
                Toast.makeText(this, "Un téléchargement est déjà en cours", Toast.LENGTH_LONG).show()
            } else {
                Saver.running = true; Saver.message = ""; Saver.startedAt = System.currentTimeMillis()
                startForegroundService(Intent(this, DownloadService::class.java).putExtra("url", url))
            }
        }
        finish()
    }
}
