package com.adam.tahmil

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.net.http.SslError
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*

class LoginActivity : Activity() {
    private lateinit var site: String
    private lateinit var cookieUrl: String
    private lateinit var domain: String
    private lateinit var need: List<String>
    private lateinit var info: TextView
    private lateinit var wv: WebView
    private var saved = false
    private var err = false

    private fun problem(t: String) { err = true; info.visibility = View.VISIBLE; info.text = "$t\n(touchez ici pour réessayer)" }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val fb = intent.getStringExtra("site") == "facebook"
        site = if (fb) "facebook" else "instagram"
        cookieUrl = if (fb) "https://www.facebook.com" else "https://www.instagram.com"
        domain = if (fb) ".facebook.com" else ".instagram.com"
        need = if (fb) listOf("c_user", "xs") else listOf("sessionid")
        val loginUrl = if (fb) "https://m.facebook.com/login/" else "https://www.instagram.com/accounts/login/"

        info = Ui.tv(c, "Chargement…", 12f, "#FDE68A").apply {
            setBackgroundColor(Color.parseColor("#1E1B2E")); setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8))
            setOnClickListener { err = false; text = "Chargement…"; wv.loadUrl(loginUrl) }
        }
        wv = WebView(c)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) {
                if (err) return
                if (p < 100) { info.visibility = View.VISIBLE; info.text = "Chargement… $p %" } else info.visibility = View.GONE
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onReceivedError(v: WebView?, r: WebResourceRequest?, e: WebResourceError?) {
                if (r?.isForMainFrame == true) problem("❌ Page non chargée : ${e?.description}. Vérifiez votre connexion (Réglages → Diagnostic).")
            }
            override fun onReceivedSslError(v: WebView?, h: SslErrorHandler?, e: SslError?) {
                h?.cancel(); problem("❌ Erreur de sécurité (SSL ${e?.primaryError}). Vérifiez la date et l'heure du téléphone.")
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                if (!saved && have()) { save(); return }
                v?.postDelayed({
                    v.evaluateJavascript("(document.body&&document.body.innerText||'').length") { r ->
                        val n = r?.trim('"')?.toIntOrNull() ?: 0
                        if (n < 20 && !saved && !err) problem("⚠️ Page vide : le WebView de ce téléphone est peut-être trop ancien.")
                    }
                }, 3000)
            }
        }
        wv.loadUrl(loginUrl)

        val top = LinearLayout(c).apply {
            setBackgroundColor(Color.BLACK); gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 32), Ui.dp(c, 12), Ui.dp(c, 8))
            addView(Ui.tv(c, if (fb) "Connexion Facebook" else "Connexion Instagram", 16f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.btn(c, "Terminé", "#16A34A", "#16A34A") {
                if (have()) save() else Toast.makeText(c, "Connexion non détectée. Connectez-vous d'abord.", Toast.LENGTH_LONG).show()
            }, LinearLayout.LayoutParams(-2, Ui.dp(c, 44)))
        }
        setContentView(LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(top); addView(info, LinearLayout.LayoutParams(-1, -2)); addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    private fun raw() = CookieManager.getInstance().getCookie(cookieUrl) ?: ""
    private fun have() = raw().let { r -> need.all { r.contains("$it=") } }

    private fun save() {
        val lines = raw().split(";").map { it.trim() }.filter { it.contains("=") }.map { p ->
            val i = p.indexOf('=')
            "$domain\tTRUE\t/\tTRUE\t2147483647\t${p.substring(0, i)}\t${p.substring(i + 1)}"
        }
        Saver.cookieFile(this, site).writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
        saved = true
        Toast.makeText(this, "✅ Compte connecté", Toast.LENGTH_SHORT).show()
        finish()
    }
}
