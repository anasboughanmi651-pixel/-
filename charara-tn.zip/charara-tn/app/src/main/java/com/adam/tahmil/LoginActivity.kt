package com.adam.tahmil

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class LoginActivity : Activity() {
    private lateinit var site: String
    private lateinit var cookieUrl: String
    private lateinit var domain: String
    private lateinit var need: List<String>
    private var saved = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val fb = intent.getStringExtra("site") == "facebook"
        site = if (fb) "facebook" else "instagram"
        cookieUrl = if (fb) "https://www.facebook.com" else "https://www.instagram.com"
        domain = if (fb) ".facebook.com" else ".instagram.com"
        need = if (fb) listOf("c_user", "xs") else listOf("sessionid")

        val wv = WebView(c)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { if (!saved && have()) save() }
        }
        wv.loadUrl(if (fb) "https://m.facebook.com/login/" else "https://www.instagram.com/accounts/login/")

        val top = LinearLayout(c).apply {
            setBackgroundColor(Color.BLACK); gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 32), Ui.dp(c, 12), Ui.dp(c, 8))
            addView(Ui.tv(c, if (fb) "Connexion Facebook" else "Connexion Instagram", 16f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.btn(c, "Terminé", "#16A34A", "#16A34A") {
                if (have()) save() else Toast.makeText(c, "Connexion non détectée. Connectez-vous d'abord.", Toast.LENGTH_LONG).show()
            }, LinearLayout.LayoutParams(-2, Ui.dp(c, 44)))
        }
        setContentView(LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(top); addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        Toast.makeText(c, "Connectez-vous : la fenêtre se fermera toute seule.", Toast.LENGTH_LONG).show()
    }

    private fun raw() = CookieManager.getInstance().getCookie(cookieUrl) ?: ""
    private fun have() = raw().let { r -> need.all { r.contains("$it=") } }

    private fun save() {
        val lines = raw().split(";").map { it.trim() }.filter { it.contains("=") }.map { p ->
            val i = p.indexOf('=')
            "$domain\tTRUE\t/\tTRUE\t2147483647\t${p.substring(0, i)}\t${p.substring(i + 1)}"
        }
        Saver.cookieFile(this, site).writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
        saved = true
        Toast.makeText(this, "✅ Compte connecté", Toast.LENGTH_SHORT).show()
        finish()
    }
}
