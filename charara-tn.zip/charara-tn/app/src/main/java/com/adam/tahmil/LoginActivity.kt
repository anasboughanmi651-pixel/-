package com.adam.tahmil

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.io.File

class LoginActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val wv = WebView(c).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.instagram.com/accounts/login/")
        }
        val top = LinearLayout(c).apply {
            setBackgroundColor(Color.BLACK); gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 16), Ui.dp(c, 32), Ui.dp(c, 12), Ui.dp(c, 8))
            addView(Ui.tv(c, "Connexion Instagram", 16f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.btn(c, "Terminé", "#16A34A", "#16A34A") { save() }, LinearLayout.LayoutParams(-2, Ui.dp(c, 44)))
        }
        setContentView(LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(top); addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    private fun save() {
        val raw = CookieManager.getInstance().getCookie("https://www.instagram.com") ?: ""
        if (!raw.contains("sessionid")) {
            Toast.makeText(this, "Connexion non détectée. Connectez-vous, puis appuyez sur Terminé.", Toast.LENGTH_LONG).show()
            return
        }
        val lines = raw.split(";").map { it.trim() }.filter { it.contains("=") }.map { p ->
            val i = p.indexOf('=')
            ".instagram.com\tTRUE\t/\tTRUE\t2147483647\t${p.substring(0, i)}\t${p.substring(i + 1)}"
        }
        File(filesDir, Saver.COOKIES).writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
        Toast.makeText(this, "✅ Instagram connecté", Toast.LENGTH_SHORT).show()
        finish()
    }
}
