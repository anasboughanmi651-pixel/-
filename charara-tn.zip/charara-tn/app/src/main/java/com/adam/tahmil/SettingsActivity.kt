package com.adam.tahmil

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import java.io.File

class SettingsActivity : Activity() {
    private lateinit var igStatus: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val page = Ui.page(c)
        page.addView(LinearLayout(c).apply {
            addView(Ui.tv(c, "←", 26f).apply { setPadding(0, 0, Ui.dp(c, 16), 0); setOnClickListener { finish() } })
            addView(Ui.tv(c, "Réglages", 24f, bold = true))
        })

        fun section(title: String, body: String) = Ui.card(c).apply {
            addView(Ui.tv(c, title, 16f, "#C4B5FD", true))
            addView(Ui.tv(c, body, 13f, "#CBD5E1"), Ui.lp(c, 6))
        }

        igStatus = Ui.tv(c, "", 13f, "#A78BFA", true)
        page.addView(section("Compte Instagram",
            "Instagram bloque parfois le téléchargement des Reels sans compte. Connectez-vous une fois pour que les Reels se téléchargent correctement. " +
            "Votre session reste sur votre téléphone et n'est envoyée qu'à Instagram.").apply {
            addView(igStatus, Ui.lp(c, 8))
            addView(Ui.btn(c, "Se connecter à Instagram", "#E11D48", "#8B5CF6") { startActivity(Intent(c, LoginActivity::class.java)) },
                LinearLayout.LayoutParams(-1, Ui.dp(c, 48)).apply { topMargin = Ui.dp(c, 10) })
            addView(Ui.btn(c, "Se déconnecter", "#334155", "#334155") { File(filesDir, Saver.COOKIES).delete(); refresh() },
                LinearLayout.LayoutParams(-1, Ui.dp(c, 48)).apply { topMargin = Ui.dp(c, 8) })
        }, Ui.lp(c, 20))

        page.addView(section("Comment utiliser",
            "1. Ouvrez une vidéo dans Facebook, TikTok ou Instagram.\n" +
            "2. Appuyez sur Partager, puis Copier le lien.\n" +
            "3. Ouvrez l'application, collez le lien et appuyez sur Télécharger.\n" +
            "Astuce : Partager → CHARARA => TN remplit le lien automatiquement."), Ui.lp(c, 12))

        page.addView(section("Bouton flottant",
            "Activez-le sur l'écran d'accueil. Copiez le lien d'une vidéo, puis appuyez sur le bouton : la vidéo se télécharge en arrière-plan et arrive dans la Galerie (album CHARARA TN). " +
            "Android demande l'autorisation « Afficher par-dessus les autres applications » et les notifications. " +
            "Si le bouton disparaît, désactivez l'optimisation de la batterie pour l'application."), Ui.lp(c, 12))

        page.addView(section("Limites",
            "Seules les vidéos publiques sont prises en charge. Les Stories, comptes privés et publications réservées aux amis ne fonctionnent pas. " +
            "Les réseaux sociaux changent souvent : si un téléchargement échoue, installez la dernière version de l'application."), Ui.lp(c, 12))

        page.addView(section("À propos", "Version 1.1\nTéléchargez vos vidéos préférées, sans publicité."), Ui.lp(c, 12))
        page.addView(Ui.footer(c), Ui.lp(c, 28))
        setContentView(ScrollView(c).apply { isFillViewport = true; addView(page) })
    }

    private fun refresh() {
        igStatus.text = if (File(filesDir, Saver.COOKIES).exists()) "● Connecté" else "○ Non connecté"
    }

    override fun onResume() { super.onResume(); refresh() }
}
