package com.adam.tahmil

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.widget.*
import java.io.File

class SettingsActivity : Activity() {
    private var refreshAcc: () -> Unit = {}
    private lateinit var err: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val c = this
        val page = Ui.page(c)
        page.addView(LinearLayout(c).apply {
            addView(Ui.tv(c, "←", 26f).apply { setPadding(0, 0, Ui.dp(c, 16), 0); setOnClickListener { finish() } })
            addView(Ui.tv(c, "Réglages", 24f, bold = true))
        })

        fun section(title: String, body: String) = Ui.card(c).apply {
            addView(Ui.tv(c, title, 16f, "#C4B5FD", true))
            addView(Ui.tv(c, body, 13f, "#CBD5E1"), Ui.lp(c, 6))
        }

        val (acc, r) = Ui.accounts(c); refreshAcc = r
        page.addView(acc, Ui.lp(c, 20))

        val prefs = getSharedPreferences("app", Context.MODE_PRIVATE)
        page.addView(Ui.card(c).apply {
            addView(Switch(c).apply {
                text = "Économiser les données (480p max)"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("low", false)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("low", on).apply() }
            })
            addView(Ui.tv(c, "Vidéos plus légères et plus rapides : idéal si votre connexion est lente.", 12f, "#94A3B8"), Ui.lp(c, 6))
        }, Ui.lp(c, 12))

        page.addView(section("Comment utiliser",
            "1. Ouvrez une vidéo dans Facebook, TikTok ou Instagram.\n" +
            "2. Appuyez sur Partager, puis Copier le lien.\n" +
            "3. Ouvrez l'application, collez le lien et appuyez sur Télécharger.\n" +
            "Astuce : Partager → CHARARA => TN remplit le lien automatiquement."), Ui.lp(c, 12))

        page.addView(section("Bouton flottant",
            "Activez-le sur l'écran d'accueil. Copiez le lien d'une vidéo, puis appuyez sur le bouton : la vidéo se télécharge en arrière-plan et arrive dans la Galerie (album CHARARA TN). " +
            "Android demande l'autorisation « Afficher par-dessus les autres applications » et les notifications. " +
            "Si le bouton disparaît, désactivez l'optimisation de la batterie pour l'application."), Ui.lp(c, 12))

        page.addView(section("Compte et confidentialité",
            "Chaque personne se connecte avec son propre compte, une seule fois. La session est enregistrée uniquement sur votre téléphone (aucun serveur) et n'est utilisée que pour télécharger vos vidéos. " +
            "Vous pouvez vous déconnecter à tout moment. Un usage très intensif peut être limité par Instagram ou Facebook."), Ui.lp(c, 12))

        page.addView(section("Limites",
            "Les vidéos privées d'un compte que vous ne suivez pas ne peuvent pas être téléchargées. Les publications avec photos seulement non plus. " +
            "Les réseaux sociaux changent souvent : si un téléchargement échoue, installez la dernière version de l'application."), Ui.lp(c, 12))

        err = Ui.tv(c, "", 12f, "#FCA5A5")
        page.addView(Ui.card(c).apply {
            addView(Ui.tv(c, "Dernière erreur", 16f, "#C4B5FD", true))
            addView(err, Ui.lp(c, 6))
            addView(Ui.btn(c, "Copier l'erreur", "#334155", "#334155") {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("erreur", err.text))
                Toast.makeText(c, "Copié", Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(-1, Ui.dp(c, 44)).apply { topMargin = Ui.dp(c, 8) })
        }, Ui.lp(c, 12))

        val wvv = try { WebView.getCurrentWebViewPackage()?.let { it.packageName + " " + it.versionName } } catch (e: Throwable) { null } ?: "inconnu"
        val netOut = Ui.tv(c, "WebView : $wvv", 12f, "#CBD5E1")
        page.addView(Ui.card(c).apply {
            addView(Ui.tv(c, "Diagnostic", 16f, "#C4B5FD", true))
            addView(netOut, Ui.lp(c, 6))
            addView(Ui.btn(c, "Tester la connexion", "#334155", "#334155") {
                netOut.text = "Test en cours…"
                Thread {
                    val sb = StringBuilder("WebView : $wvv\n")
                    for (u in listOf("https://www.facebook.com", "https://www.instagram.com", "https://www.tiktok.com", "https://www.google.com")) {
                        val t0 = System.currentTimeMillis()
                        val r = try {
                            val cn = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                            cn.connectTimeout = 8000; cn.readTimeout = 8000
                            cn.setRequestProperty("User-Agent", "Mozilla/5.0")
                            "OK (${cn.responseCode}) ${System.currentTimeMillis() - t0} ms"
                        } catch (e: Exception) { "ÉCHEC : ${e.javaClass.simpleName}" }
                        sb.append(u.removePrefix("https://www.")).append(" → ").append(r).append("\n")
                    }
                    runOnUiThread { netOut.text = sb.toString().trim() }
                }.start()
            }, LinearLayout.LayoutParams(-1, Ui.dp(c, 44)).apply { topMargin = Ui.dp(c, 8) })
        }, Ui.lp(c, 12))

        page.addView(section("À propos", "Version 1.4\nTéléchargez vos vidéos préférées, sans publicité."), Ui.lp(c, 12))
        page.addView(Ui.footer(c), Ui.lp(c, 28))
        setContentView(ScrollView(c).apply { isFillViewport = true; addView(page) })
    }

    override fun onResume() {
        super.onResume()
        refreshAcc()
        val f = File(filesDir, "last_error.txt")
        err.text = if (f.exists()) f.readText().take(500) else "Aucune erreur enregistrée"
    }
}
