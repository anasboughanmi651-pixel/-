package com.adam.tahmil

import android.app.*
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast

class DownloadService : Service() {
    private val ui = Handler(Looper.getMainLooper())

    companion object { @Volatile private var working = false }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "cancel") { Saver.cancel(); return START_NOT_STICKY }
        val url = i?.getStringExtra("url")
        if (url == null) { Saver.running = false; stopSelf(); return START_NOT_STICKY }
        if (working) return START_NOT_STICKY
        working = true
        startForeground(2, notif(-1, "Analyse du lien…"))
        val nm = getSystemService(NotificationManager::class.java)
        val tick = object : Runnable {
            override fun run() {
                if (!working) return
                val (pct, txt) = Saver.parse(Saver.progress())
                nm.notify(2, notif(pct, txt))
                ui.postDelayed(this, 1000)
            }
        }
        ui.postDelayed(tick, 1000)
        Thread {
            val msg = try {
                "✅ Terminé ! Retrouvez-la dans la Galerie\n" + Saver.fetch(applicationContext, url)
            } catch (e: Throwable) {
                "❌ " + Saver.fail(applicationContext, e)
            }
            Saver.message = msg; Saver.running = false; working = false
            ui.post {
                stopForeground(true)
                val first = msg.lineSequence().first()
                nm.notify(3, Notification.Builder(this, "d").setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡").setContentText(first).setAutoCancel(true).build())
                Toast.makeText(this, first, Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun notif(pct: Int, text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("d", "Téléchargements", NotificationManager.IMPORTANCE_LOW))
        val cancel = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction("cancel"), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "d").setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("𝗖𝗛𝗔𝗥𝗔𝗥𝗔 => 𝗧𝗡").setContentText(text)
            .setProgress(100, maxOf(pct, 0), pct < 0).setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Annuler", cancel).build()).build()
    }
}
